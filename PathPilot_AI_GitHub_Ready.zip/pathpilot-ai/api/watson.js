import { watsonConfig, watsonMessage } from "../lib/watson.mjs";

export default async function handler(request, response) {
  if (request.method !== "POST") return response.status(405).json({ error: "Method not allowed." });
  const text = request.body?.text;
  if (!text || typeof text !== "string") return response.status(400).json({ error: "A text message is required." });
  try {
    response.status(200).json({ reply: await watsonMessage(text.slice(0, 1000)) });
  } catch (error) {
    response.status(watsonConfig() ? 502 : 503).json({ error: error.message });
  }
}
