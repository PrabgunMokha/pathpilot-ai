import { watsonConfig } from "../lib/watson.mjs";

export default function handler(_request, response) {
  response.status(200).json({ watsonConfigured: Boolean(watsonConfig()) });
}
