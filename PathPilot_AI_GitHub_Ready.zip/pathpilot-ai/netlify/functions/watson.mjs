import { watsonConfig, watsonMessage } from "../../lib/watson.mjs";

export async function handler(event) {
  if (event.httpMethod !== "POST") return result(405, { error: "Method not allowed." });
  let body;
  try { body = JSON.parse(event.body || "{}"); } catch { return result(400, { error: "Invalid JSON." }); }
  if (!body.text || typeof body.text !== "string") return result(400, { error: "A text message is required." });
  try {
    return result(200, { reply: await watsonMessage(body.text.slice(0, 1000)) });
  } catch (error) {
    return result(watsonConfig() ? 502 : 503, { error: error.message });
  }
}

function result(statusCode, body) {
  return { statusCode, headers: { "content-type": "application/json" }, body: JSON.stringify(body) };
}
