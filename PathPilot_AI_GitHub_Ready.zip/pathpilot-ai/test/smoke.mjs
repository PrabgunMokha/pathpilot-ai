import { spawn } from "node:child_process";
import { setTimeout as wait } from "node:timers/promises";

const port = 3107;
const child = spawn(process.execPath, ["server.js"], {
  env: { ...process.env, PORT: String(port), WATSON_API_KEY: "", WATSON_ASSISTANT_ID: "", WATSON_ASSISTANT_URL: "" },
  stdio: ["ignore", "pipe", "inherit"]
});

try {
  await Promise.race([
    new Promise(resolve => child.stdout.once("data", resolve)),
    wait(5000).then(() => { throw new Error("Server did not start in time."); })
  ]);
  const home = await fetch(`http://127.0.0.1:${port}/`);
  const html = await home.text();
  const status = await fetch(`http://127.0.0.1:${port}/api/status`);
  const statusBody = await status.json();
  const watson = await fetch(`http://127.0.0.1:${port}/api/watson/message`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ text: "hello" })
  });

  if (home.status !== 200 || !html.includes("PathPilot AI")) throw new Error("Home page check failed.");
  if (status.status !== 200 || statusBody.watsonConfigured !== false) throw new Error("Status endpoint check failed.");
  if (watson.status !== 503) throw new Error("Missing-key safety check failed.");
  console.log("Smoke test passed: page, status endpoint and missing-key fallback are working.");
} finally {
  child.kill();
}
